PACOTE DE ÍCONES — IFBA-PS KEYCHAIN

Arquivos principais:
- icon-72x72.png até icon-512x512.png: ícones padrão da PWA.
- icon-maskable-192x192.png e icon-maskable-512x512.png: ícones com margem segura para Android.
- favicon.ico: favicon com 16, 32 e 48 pixels.
- favicon-16x16.png, favicon-32x32.png e favicon-48x48.png.
- apple-touch-icon.png: ícone para iPhone/iPad, 180x180.
- mstile-150x150.png: compatibilidade com atalhos da Microsoft.
- logo-ifba-ps-keychain-512x512.png e 1024x1024.png: logotipo completo.
- key-symbol-1024x1024.png: símbolo da chave em alta resolução.
- manifest-icons.json: bloco pronto para copiar para o manifest.webmanifest.

USO NO ANGULAR:
1. Copie os arquivos para src/assets/icons/.
2. Copie o conteúdo de manifest-icons.json para a propriedade "icons"
   do arquivo src/manifest.webmanifest.
3. Coloque favicon.ico em src/favicon.ico ou ajuste angular.json.
4. Para Apple Touch Icon, adicione no index.html:
   <link rel="apple-touch-icon" href="assets/icons/apple-touch-icon.png">

Observação:
Os ícones pequenos usam somente a chave, pois textos muito pequenos ficam ilegíveis
na tela inicial, na aba do navegador e nas notificações.
