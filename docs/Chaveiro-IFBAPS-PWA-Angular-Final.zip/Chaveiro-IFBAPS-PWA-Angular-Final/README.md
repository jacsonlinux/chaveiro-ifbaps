# Chaveiro IFBAPS — identidade visual e ícones PWA

Pacote definitivo para o aplicativo Angular/Firebase do IFBA Campus Porto Seguro. A arte utiliza a chave metálica aprovada como letra **I** e dez módulos verdes formando a letra **F**.

## Instalação rápida

### Angular com diretório `src/`

Copie o conteúdo da pasta `src/` deste pacote para o `src/` do projeto:

```text
src/
├── assets/icons/           # todos os ícones PNG
├── browserconfig.xml       # integração com blocos Windows, opcional
├── favicon.ico             # favicon multirresolução
└── manifest.webmanifest    # manifesto PWA completo
```

Se o projeto já possuir um manifesto, preserve as configurações específicas do aplicativo e substitua apenas os campos de identidade visual e a lista `icons`.

### Angular com diretório `public/`

Nos projetos Angular mais recentes, copie o conteúdo da pasta `src/` deste pacote para `public/`, mantendo `public/assets/icons`, `public/favicon.ico` e `public/manifest.webmanifest`.

### Tags no HTML

Adicione as tags de `index-head.snippet.html` ao `<head>` do `src/index.html`, sem duplicar elementos já existentes.

### Service worker

Caso o projeto ainda não tenha PWA configurado:

```bash
ng add @angular/pwa
```

Se já houver um `ngsw-config.json`, confira as entradas apresentadas em `ngsw-config.snippet.json`; não substitua grupos de cache próprios do projeto.

### Build e publicação

```bash
ng build --configuration production
firebase deploy --only hosting
```

O arquivo `firebase.headers.snippet.json` contém cabeçalhos opcionais para incorporar ao `firebase.json` existente. Não substitua a configuração completa do projeto por esse fragmento.

## Conteúdo

- Arte-fonte aprovada em `source/icon-original-1254x1254.png`.
- Matriz tratada em `src/assets/icons/icon-master-1024x1024.png`.
- Ícones PWA: 48, 64, 72, 96, 120, 128, 144, 150, 152, 167, 180, 192, 256, 310, 384 e 512 pixels.
- Ícones adaptativos/maskable: 192 e 512 pixels com margem segura.
- Favicons PNG: 16, 32, 48 e 64 pixels, mais `favicon.ico` multirresolução.
- Apple Touch Icons: 120, 152, 167 e 180 pixels.
- Android/Chrome: 192 e 512 pixels.
- Microsoft Tiles: 70, 150 e 310 pixels, além de tile largo 310 × 150.
- Manifesto PWA completo, fragmento para `<head>`, exemplos de cache/service worker e cabeçalhos Firebase.

## Atualização de dispositivos

Navegadores e PWAs podem manter ícones antigos em cache. Depois do deploy, atualize a aplicação, aguarde a atualização do service worker e, se necessário, remova e reinstale o PWA no dispositivo.

Cor de tema recomendada: `#368C2B`. Fundo: `#FFFFFF`.
