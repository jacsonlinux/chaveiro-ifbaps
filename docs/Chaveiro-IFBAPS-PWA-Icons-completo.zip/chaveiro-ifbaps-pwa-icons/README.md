# Ícones PWA — Chaveiro IFBAPS

Pacote de ícones para o sistema de controle de chaves do IFBA Campus Porto Seguro. O desenho usa um cadeado verde e uma chave vermelha, com fundo branco e área segura para ícones adaptativos (maskable).

## Instalação no Angular

1. Copie a pasta `assets/icons` para `src/assets/icons` do projeto Angular.
2. Em `src/manifest.webmanifest`, substitua ou acrescente o conteúdo de `manifest-icons.json` no objeto do manifesto. Ajuste os caminhos caso o seu projeto use outro diretório público.
3. Inclua no `src/index.html`:

```html
<link rel="icon" href="assets/icons/favicon.ico" sizes="any">
<link rel="apple-touch-icon" href="assets/icons/apple-touch-icon-180x180.png">
<meta name="theme-color" content="#007A33">
```

4. Gere uma nova versão/deploy para que navegadores atualizem o cache do ícone.

## Arquivos

- `icon-source.svg`: matriz vetorial editável.
- `assets/icons/`: ícones PNG em todos os tamanhos necessários, versões maskable, Apple Touch Icon e favicon.
- `manifest-icons.json`: bloco pronto para o `manifest.webmanifest`.

Os PNGs não incluem texto: isso preserva legibilidade nos tamanhos pequenos.
